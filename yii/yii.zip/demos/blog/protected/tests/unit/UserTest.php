<?php

class UserTest extends CDbTestCase
{
	public $fixtures=array(
		'users'=>'User',
	);

	public function testCreate()
	{

	}
}